<?php

/**
 * Mock of WC_Object_Query for testing WC_Object_Query in isolation.
 */
class WC_Mock_WC_Object_Query extends WC_Object_Query {}
