<?php
/**
 * WC Unit Test Factory
 *
 * Provides WooCommerce-specific factories.
 *
 * @since 2.2
 */
class WC_Unit_Test_Factory extends WP_UnitTest_Factory {

	/**
	 * Setup factories.
	 */
	public function __construct() {
		parent::__construct();
	}
}
