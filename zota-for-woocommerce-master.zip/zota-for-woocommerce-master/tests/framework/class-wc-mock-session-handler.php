<?php
/**
 * WooCommerce Mock Session Handler
 *
 * @since 2.2
 */
class WC_Mock_Session_Handler extends WC_Session { }
